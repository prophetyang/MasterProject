#ifndef _IPT_LENGTH_H
#define _IPT_LENGTH_H

struct ipt_length_info {
    u_int16_t	min, max;
    u_int8_t	invert;
};

#endif /*_IPT_LENGTH_H*/
