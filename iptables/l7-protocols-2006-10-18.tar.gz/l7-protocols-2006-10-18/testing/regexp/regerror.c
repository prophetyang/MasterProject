#if 0
void regerror(char * s)
{
	printk("regexp(3): %s", s);
	/* NOTREACHED */
}
#endif
